1. To compile to program, simply type `gcc test.c -o test`
2. Run it with typing `./test`
3. Make sure all the files (1.txt, test.c and Md5.c are in the same directory)